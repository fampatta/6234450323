package lab12_3;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;

public class FileMatch {    
    public static void main(String[] args) {
        try
        {
            ArrayList<AccountRecord> accountRec = new ArrayList<>();
            ArrayList<TransactionRecord> transRec = new ArrayList<>(); 
            File accFile = new File("master.txt");         
            Scanner textAcc = new Scanner(accFile);           
            while(textAcc.hasNextLine()){
                String str1 = textAcc.nextLine();
                String[] acc = str1.split(" ");
                int no = Integer.parseInt(acc[0]);
                String name = acc[1]+" "+acc[2];
                double balance = Double.parseDouble(acc[3]);                     
                accountRec.add(new AccountRecord(no,name,balance));    
            }  

            textAcc.close();
            File transFile = new File("trans.txt");         
            Scanner textTrans = new Scanner(transFile);
            while(textTrans.hasNextLine()){
                String str2 = textTrans.nextLine();
                String[] trans = str2.split(" ");
                int no2 = Integer.parseInt(trans[0]);                
                double transText = Double.parseDouble(trans[1]);                     
                transRec.add(new TransactionRecord(no2,transText));    
            }   
            textTrans.close();
            
            RandomAccessFile masFile = new RandomAccessFile("newMaster.dat","rw"); 
            double total = 0;
            int countNotTrans = 0;
            int line = 0;
            for(AccountRecord a:accountRec){
                double oldBalance = a.getBalance();
                for(TransactionRecord t:transRec){
                    a.combine(t); 

                }
                if (a.getTransCnt() == 0)countNotTrans++;                  
                masFile.writeInt(a.getAcctNo());
                masFile.writeChar(' ');
                int len = a.getName().length();
                if (len != 30){
                    int fill = 30-len;
                    masFile.writeChars(a.getName());
                    for(int i= 0 ; i != fill ;i++){masFile.writeChar(' ');}                   
                }
                masFile.writeChar(' ');    
                masFile.writeDouble(a.getBalance());
                total += a.getBalance();
                line++;
                masFile.writeChar('\n');                    
            }           
            System.out.print("Total Account Record : "+line+"\n");
            System.out.println("Total balance : "+total);
            System.out.print("No transaction : "+countNotTrans+" account.\n");                    
        }
        catch(IOException e){System.out.println(e);}
    }
}
