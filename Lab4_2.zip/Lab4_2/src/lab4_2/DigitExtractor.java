package lab4_2;

public class DigitExtractor {
    private int integer, n;        
    public DigitExtractor(int anInteger){
        integer = anInteger;
        n = 1;
    }

    public int nextDigit(){        
        int digit = (int)(integer%Math.pow(10,n)/Math.pow(10,n-1));
        n = n+1;
        return digit;       
    }    
}
