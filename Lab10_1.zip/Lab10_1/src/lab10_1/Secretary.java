package lab10_1;

public class Secretary extends Employee implements Evaluation {
    private int typingSpeed;
    private int[]score;

    public Secretary(String name,int salary,int[]sc,int typingSpeed) {
        super(name, salary);
        this.score = sc;
        this.typingSpeed = typingSpeed;
    }

    @Override
    public double evaluate() {
        double sum = 0;
        for(int sc:score){
            sum+=sc;
        }
        return sum;
    }

    @Override
    public char grade(double evaluate) {
        if (evaluate >= 90){
            super.setSalary(18000);
            return 'P';
        }
        else return 'F';
    }
    
}
