package lab10_1;

public class Subject implements Evaluation  {
    private String subjName;
    private int[] score;
    public Subject(String name,int[] sc){
        this.subjName = name;
        this.score = sc;
    }

    @Override
    public double evaluate() {
        double sum = 0;
        for(int sc:score){
            sum+=sc;
        }
        return sum/score.length;
    }

    @Override
    public char grade(double evaluate) {
        if (evaluate >= 70){
            return 'P';
        }
        else return 'F';
    }
    
    @Override 
    public String toString(){
        return subjName;
    }
}
