package lab5_2;

import java.awt.geom.Point2D;
import static java.lang.Double.NaN;

public class Line {
    private double x,m,b;    
    public Line(double x, double y, double m){
        this.x=NaN;
        this.b=y-(m*x);
        this.m=m;
    }
    public Line(double x1, double y1,double x2, double y2){
        this.x=NaN;
        this.m = (y2-y1)/(x2-x1);
        this.b=y1-(m*x1);
    }
    public Line(double m, double b){
        this.m=m;
        this.b=b; 
        this.x=NaN;
    }
    public Line(double a){
        this.x=a;
        this.b = NaN;
        this.m = NaN;
    }
    
    public boolean isParallel(Line line){
        boolean check = false;
        if(Double.isNaN(this.m)&Double.isNaN(line.m))
          check = true;
        else check = this.m == line.m;
        return check;            
    }
    public boolean equals(Line line){
        boolean check = false;
        if(Double.isNaN(this.m)&Double.isNaN(line.m)){            
           check = true;
        }
        else check = (this.m == line.m)&(this.b == line.b);
        return check; 
    }    
    public boolean isIntersect(Line line){        
        return !this.isParallel(line);        
    }
    public Point2D.Double getIntersectionPoint(Line line){    
        double pX = 0;
        double pY = 0;
        Point2D.Double line1 = new Point2D.Double();
        if(Double.isNaN(this.m) & Double.isNaN(this.b)){
            pX = this.x;
            pY = (line.m*pX)+line.b;
            line1.setLocation(pX,pY);
        } 
        else if(Double.isNaN(line.x) & Double.isNaN(this.x)){
            pX = (line.b-this.b)/(this.m-line.m);
            pY = (this.m*pX)+this.b;
            line1.setLocation(pX,pY);
        }      
        else if (Double.isNaN(line.m) & Double.isNaN(line.b)){
            pX = line.x;
            pY = (this.m*pX)+this.b;
            line1.setLocation(pX,pY);
        }
        return line1;
    }
}
