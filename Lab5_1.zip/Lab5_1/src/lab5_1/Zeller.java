package lab5_1;
enum Day{ 
    SUNDAY("Sunday"), MONDAY("Monday"),
    TUESDAY("Tuesday"),WEDNESDAY("Wednesday"),
    THURSDAY("Thursday"),FRIDAY("Friday"), 
    SATURDAY("Saturday");
    private final String day;    
    Day(String day){
        this.day = day;
    }    
    public String getDay(){
        return day;
    }
}
    
public class Zeller {
    private int year,month,dayOfMonth;
    public Zeller(int year,int month,int dayOfMonth){
        this.year = year;
        this.month = month;
        this.dayOfMonth = dayOfMonth;        
    }
    public Day getDayOfWeek(){
        int j = year/100;
        int k = year%100;
        int h = dayOfMonth+((26*(month+1))/10)+k+(k/4)+(j/4)+(j*5);
        h = h%7;
        Day d = null;
        switch (h){
            case 0:d = Day.SATURDAY;break;
            case 1:d = Day.SUNDAY;break;
            case 2:d = Day.MONDAY;break;
            case 3:d = Day.TUESDAY;break;
            case 4:d = Day.WEDNESDAY;break;
            case 5:d = Day.THURSDAY;break;
            case 6:d = Day.FRIDAY;break;
        }
        return d;
    }
}






    



