package lab9_1;
import java.util.ArrayList;

public class Customer{
    private String name,tel;
    public Customer(String name,String tel){
        this.name = name;
        this.tel = tel;
    }
        
    @Override
    public String toString(){
        return getName()+" Tel : "+getTel();
    }

    public String getName(){
        return name;
    }
    public String getTel(){
        return tel;
    }
    
}
