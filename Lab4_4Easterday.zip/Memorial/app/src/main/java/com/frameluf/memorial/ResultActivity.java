package com.frameluf.memorial;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ResultActivity extends AppCompatActivity {
    String result;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.result_activity);
        TextView date = findViewById(R.id.txt1);
        result = getIntent().getStringExtra("year");
        date.setText(result);
    }
}
