package lab4_3;
import java.util.Scanner;

public class TimeIntervalTester {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter start time: ");
        int start = sc.nextInt();
        System.out.print("Enter end time: ");
        int end = sc.nextInt();
        TimeInterval demo = new TimeInterval(start,end);
        System.out.println(demo.getHours()+" hours "+demo.getMinutes()+" minutes");       
    }
}
