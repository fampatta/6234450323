package lab4_3;
import java.lang.Math;
public class TimeInterval {
    private int start,end,hoursS,minutesS,hoursE,minutesE;       
    public TimeInterval(int start,int end){        
        hoursS = (start/100)*60;
        minutesS = start%100;
        hoursE = (end/100)*60; 
        minutesE = end%100;
        this.start = hoursS+minutesS;
        this.end = hoursE+minutesE; 
    }
    public int getHours(){     
        int h = (int)(Math.abs(end-start)/60);        
        return h;
    }
    public int getMinutes(){
        int h = (int)(Math.abs(end-start)/60);
        int m = (int)(Math.abs(end-start)- h*60);
        return m;
    }
    
}
