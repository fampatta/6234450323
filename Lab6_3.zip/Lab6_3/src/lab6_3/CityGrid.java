package lab6_3;
import java.util.Random;
public class CityGrid {
    private int xCoor; 
    private int yCoor; 
    private int gridSize; 
    public CityGrid (int size){
        xCoor = size/2;
        yCoor = size/2;
        gridSize = size;
    }
    public void walk(){          
            int com;
            Random demo1 = new Random(); 
            com = demo1.nextInt(4);
            switch(com){
                case 0: xCoor++;break;
                case 1: yCoor++;break;
                case 2: xCoor--;break;
                case 3: yCoor--;break;}
    }                             
    public boolean isInCity() {        
        return xCoor <= gridSize & yCoor <= gridSize & xCoor >= 0 & yCoor >= 0; 
    }   
    public void reset(){
        xCoor = gridSize/2;
        yCoor = gridSize/2;
    }   
}
