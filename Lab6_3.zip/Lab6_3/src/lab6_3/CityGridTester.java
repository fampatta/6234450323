package lab6_3;

public class CityGridTester {
    public static void main(String[] args) {
        double n = 0;
        double t = 0;
        double maxStep = 0;
        CityGrid tester = new CityGrid(10);
        for(int a = 1;a<=10000;a++){
            for(int i = 1;i<=1000;i++){  
                if (tester.isInCity()){
                    tester.walk();
                    n++;}
                else {tester.reset();break;}}
        if (n>maxStep)
            maxStep = n;
        t += n;
        n = 0;
        }        
        System.out.printf("Average number of steps that a person can take and is still in the city: %.2f \n",t/10000);             
        System.out.println("Maximum number of steps that a person can take and is still in the city: "+(int)maxStep);
    }
}
