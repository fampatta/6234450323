package lab6_2;
import static java.lang.Math.abs;
import java.util.Random;
import java.util.Scanner;

public class Game {
    private int scorePlayer;
    private int scoreCom;
    public Game(){              
    }
    public void play(){        
        int com ;
        while(abs(scorePlayer-scoreCom)!=2){
            String player = "reset";
            while((!player.equals("0"))&(!player.equals("1"))&(!player.equals("2"))){
                Scanner demo = new Scanner(System.in);
                System.out.print("Enter 0 for , 1 for PAPER, 2 for SCISSORS: ");
                player = demo.nextLine(); 
                switch(player){
                    case "0": System.out.println("You enter: ROCK");break;
                    case "1": System.out.println("You enter: PAPER");break;
                    case "2": System.out.println("You enter: SCISSORS");break;}                               
            }
            Random demo1 = new Random(); 
            com = demo1.nextInt(3);
            switch(com){
                case 0: System.out.println("Computer: ROCK");break;
                case 1: System.out.println("Computer: PAPER");break;
                case 2: System.out.println("Computer: SCISSORS");break;}
            if ((player.equals("0") & com == 2)|(player.equals("1") & com == 0)|(player.equals("2") & com == 1)){
                System.out.println("You win!");
                scorePlayer += 1;}        
            else if ((player.equals("1") & com == 2)|(player.equals("2") & com == 0)|(player.equals("0") & com == 1)){
                System.out.println("You lose!");            
                scoreCom += 1;}            
            else if ((player.equals("0") & com == 0)|(player.equals("1") & com == 1)|(player.equals("2") & com == 2))
                System.out.println("It's a tie.");
        }    
        if (scorePlayer>scoreCom){
           System.out.println("\n----------------------------------------\n");
           System.out.println("Congrats! You win.");
           System.out.println("User Score: "+scorePlayer);
           System.out.println("Computer score: "+scoreCom);}
        else if(scoreCom>scorePlayer){
           System.out.println("\n----------------------------------------\n");
           System.out.println("Too bad! You lose.");
           System.out.println("User Score: "+scorePlayer);
           System.out.println("Computer score: "+scoreCom);}       
    }   
}
