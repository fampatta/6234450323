package lab11_2;

public interface CanWalk {
    void walk(Terrain terrain);
    void run(Terrain terrain);
}

