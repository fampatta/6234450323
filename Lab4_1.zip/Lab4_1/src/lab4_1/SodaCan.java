package lab4_1;
import java.util.Scanner;
import java.lang.Math;

public class SodaCan {

    private double height;
    private double diameter;
    
    public SodaCan                                                                                                                                () {
    }
    public SodaCan(double h,double d) {
        height = h;
        diameter = d;
    }    
    
    public double getVolume(){
        double volume = Math.PI*Math.pow((diameter/2),2)*height;  
        return volume;
    }
    public double getSurfaceArea(){
        double surface = 2*Math.PI*Math.pow((diameter/2),2)+(2*Math.PI*(diameter/2)*height);   
        return surface;
    }
   
}
