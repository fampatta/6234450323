package lab8_2;

public class NumericQuestion extends Question{
    public NumericQuestion(String text){
        super(text); 
    }   
    @Override
    public boolean checkAnswer(String response){
        double r = Double.parseDouble(response);
        double a = Double.parseDouble(getAnswer());        
        return Math.abs(a-r) <= 0.01;
    }
}
