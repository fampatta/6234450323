package lab12_2;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class tester {

    public static void main(String[] args) {
        System.out.print("Enter a sentence: ");
        Scanner input = new Scanner(System.in);
        String line = input.nextLine();
        String[] inputText = line.split(" ");
        try
        {           
            URL url = new URL("https://www.cs.duke.edu/~ola/ap/linuxwords");
            Scanner web = new Scanner(url.openStream());          
            ArrayList<String> webText = new ArrayList<>();
            while (web.hasNextLine()){
                String s = web.nextLine();
                webText.add(s);
            }
            ArrayList<String> notContained = new ArrayList<>();
            for (String i:inputText){
                boolean check = true;
                for(String j:webText){
                    if( i.equalsIgnoreCase(j)){
                        check = false;
                        break;}                                            
                }
                if(check)notContained.add(i);                                     
            }  
            System.out.println("Words not contained: ");
            if(notContained.isEmpty())
                System.out.println("N/A");
            else {
                for (String i : notContained){           
                    System.out.print(i+" ");
                }
                System.out.println();
            }
        }
        catch(IOException e){System.out.println(e);}       
    }   
}
