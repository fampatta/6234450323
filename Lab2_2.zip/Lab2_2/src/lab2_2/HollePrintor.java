package lab2_2;

public class HollePrintor {

    public static void main(String[] args) {
        String str = "\"Hello, World!\"";
        String newStr = str.replace("o","1").replace("e","o").replace("1","e");   
        System.out.println(newStr);
    }   
}
