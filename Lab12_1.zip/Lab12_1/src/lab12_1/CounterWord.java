package lab12_1;
import java.io.*;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class CounterWord {

    
    public static void main(String[] args) throws FileNotFoundException {       
        File f = new File("file.txt");      
        PrintWriter input = new PrintWriter(f);
        String str = null;        
        Scanner in = new Scanner(System.in);
        str = in.nextLine();
        while(!str.equals("quit")){
            input.println(str);  
            str = in.nextLine();
        }
        input.close();
        
        int countLine = 0;  
        int countWord = 0;  
        int countChar = 0;  
        
        Scanner output = new Scanner(f);         
        while(output.hasNextLine()){
            String line = output.nextLine();
            String[] l = line.split(" ");
            for(String i:l){
                if (i.length()!=0)
                    countWord++;
                countChar += i.length();}
            if (l.length != 0){countChar += l.length-1;}
            countLine++;
        }          
        output.close();
        System.out.println("Total characters : "+countChar);
        System.out.println("Total words : "+countWord);
        System.out.println("Total lines : "+countLine);       
    }
}
    

