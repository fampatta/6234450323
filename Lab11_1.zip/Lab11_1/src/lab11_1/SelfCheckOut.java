package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue {
    private ArrayList<Product> goods;  
    private double totalPrices;
    
    public SelfCheckOut(){
        goods = new ArrayList<>();
    } 
    
    @Override
    public void enqueue(Object o) {
        Product a = (Product)o;
        goods.add(a);
        System.out.println((a.getName())+" is added in queue");
    }

    @Override
    public void dequeue() {
        Product a = goods.get(0);
        totalPrices += a.getPrice();
        goods.remove(0);
    }
    
    public double getAmount() {
        return totalPrices;
    }
    
}
