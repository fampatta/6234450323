package lab7_2;

public class MagicSquareTester {
    public static void main(String[] args) {
        MagicSquare test = new MagicSquare(5);
        System.out.print(test.toString());
    }  
}
