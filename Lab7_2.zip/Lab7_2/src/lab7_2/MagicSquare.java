package lab7_2;
//import java.util.ArrayList;

public class MagicSquare{
    private int n;
    private String square;
    private int[][] demo;
    public MagicSquare(int n){
        this.n = n; 
        square = "";
        int i = n-1;
        int j = (n-1)/2;        
        demo = new int[n][n];
        for(int k = 1;k <= n*n;k++){
                if(j>n-1&i>n-1){
                    i -= 2;
                    j -= 1; 
                    demo[i][j] = k;}
                else if (i>n-1&j>0){                    
                    i = 0;                    
                    demo[i][j] = k;}
                else if(j>n-1&i>0){
                    j = 0; 
                    demo[i][j] = k;}
                else if(demo[i][j] != 0){
                    i -= 2;
                    j -= 1; 
                    demo[i][j] = k;}               
                else {
                    demo[i][j] = k;}                                         
            i++;
            j++;               
        }        
    }
    
    @Override
    public String toString(){        
        for(int m=0;m < demo.length;m++){
            for(int t=0;t < demo.length;t++){
                System.out.print(demo[m][t]+"\t");
            }
        System.out.println("\n");
        }
        return square;
    } 
}
