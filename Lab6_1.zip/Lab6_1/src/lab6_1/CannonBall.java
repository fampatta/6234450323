package lab6_1;

public class CannonBall {
    private double initV; 
    private double simS; 
    private double simT; 
    public static final double G = 9.81;
    public CannonBall(double u){
       initV = u;
    }
    
    public void simulatedFlight(){        
        int i = 0;
        double v = initV;
        while(v>0){
            simS += v*0.01;
            v = v-G*0.01;
            simT += 0.01;
            if(i%100 == 0){System.out.printf("Distance on %d sec: %.3f%n",i/100,simS);}
            i++;
        }
        System.out.printf("Final distance : %.3f Total time: %.2f%n",simS,simT);                                 
    }                     
    
    public double calculusFlight(double t){
        double s = initV*t-0.5*G*t*t;       
        return s;
    }
    
    public double getSimulatedTime(){
        return simT;
    }
    
    public double getSimulatedDistance(){
        return simS;
    }    
}

