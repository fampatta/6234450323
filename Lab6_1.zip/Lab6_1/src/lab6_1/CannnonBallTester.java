package lab6_1;

public class CannnonBallTester {
    public static void main(String[] args) {
        CannonBall ball = new CannonBall(100); 
        ball.simulatedFlight();
        System.out.printf("Distance from calculus equation: %.3f \n",(ball.calculusFlight(ball.getSimulatedTime())));   
    }
}
