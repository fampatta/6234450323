package lab9_2;

public class Cosine extends Taylor{
    public Cosine(int k, double x){    
        super.setIter(k);
        super.setValue(x);
    }
    @Override
    public double getApprox(){
        double approx = 0;
        for(int n = 0 ; n <= getIter() ;n++){           
            approx += (Math.pow(-1,n)*Math.pow(getValue(),2*n))/factorial(2*n);
        }            
        return approx;
    }
    
    @Override
    public void printValue(){
        System.out.println("Value from Math.cos() is "+ Math.cos(getValue())+".\nApproximated value is "+getApprox()+".");
    }
}
