package lab9_2;

public class Expo extends Taylor{

    public Expo(int k, double x){    
        super.setIter(k);
        super.setValue(x);
    }
    @Override
    public double getApprox(){
        double approx = 0;
        for (int n = 0 ; n <= getIter() ;n++){
            approx += Math.pow(getValue(), n)/factorial(n);
        }            
        return approx;
    }
    @Override
    public void printValue(){
        System.out.println("Value from Math.exp() is "+ Math.exp(getValue())+ ".\nApproximated value is "+getApprox()+".");       
    }
}
