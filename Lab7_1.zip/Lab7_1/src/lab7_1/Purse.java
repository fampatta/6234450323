package lab7_1;
import java.util.ArrayList;

public class Purse {
    private int nickel,dime,quarter;
    private ArrayList<String> purse;
    public Purse (){  
        this.purse = new ArrayList<String>();
    }
    public void addCoin(String coinName){
        purse.add(coinName);
    }
    @Override
    public String toString(){
        String at = "";
        if (purse.size() == 0) return "Purse[]" ;
        else {for(int i = 0;i< purse.size();i++){ at += purse.get(i)+",";}
        at = at.substring(0,at.length()-1);
        return "Purse["+at+"]" ;}
        
    }
    
    public ArrayList<String> reverse(){
        int j = 0;
        ArrayList<String> my1 = new ArrayList<String>();
        for(int i = purse.size()-1;i>=0;i--){ 
            my1.add(j,purse.get(i));
            j++;} 
        purse = my1;
        return purse;    
    }
    public void transfer(Purse other){
        int oldSize = purse.size();
        for(int i = 0;i < oldSize;i++){ 
            other.purse.add(purse.get(0));
            this.purse.remove(0);}
    }
    
     public boolean sameContents(Purse other){     
        boolean check = true;
        if (this.purse.size() == other.purse.size()){
            for (int i=0;i < purse.size();i++){
                if (this.purse.get(i).equals(other.purse.get(i)));                     
                else {check = false;break;}    
            }
        }
        else{
            check = false;
        }                
        return check;
    }
    
    public boolean sameCoins(Purse other){
        int asize = this.purse.size();
        int bsize = other.purse.size();
        for (int i = 0;i < asize;i++){
            switch (this.purse.get(i)){
                case "Nickel":
                    this.nickel++;
                case "Dime":
                    this.dime++;
                case "Quarter":
                    this.quarter++;                
            }
        }
        for (int j = 0;j < bsize;j++){
            switch (other.purse.get(j)){
                case "Nickel":
                    other.nickel++;
                case "Dime":
                    other.dime++;
                case "Quarter":
                    other.quarter++;              
            }
        }        
        return this.nickel == other.nickel & this.dime == other.dime & this.quarter == other.quarter;
    }   
}
