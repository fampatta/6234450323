package lab7_1;

public class PurseTester {
    public static void main(String[] args) {
        Purse testerA = new Purse();
        Purse testerB = new Purse();
        testerA.addCoin("Quarter");
        testerA.addCoin("Dime");
        testerA.addCoin("Nickel");
        testerA.addCoin("Dime");
        
        testerB.addCoin("Nickel");
        testerB.addCoin("Dime");       
        testerB.addCoin("Dime");
//        testerB.addCoin("Quarter");
        
        System.out.println(testerA.toString());
        System.out.println(testerB.toString());
        
        testerA.reverse();        
//        testerA.transfer(testerB); 

        System.out.println(testerA.toString());
        System.out.println(testerB.toString());
        
        System.out.println(testerA.sameContents(testerB));
        System.out.println(testerA.sameCoins(testerB));
    }
}
